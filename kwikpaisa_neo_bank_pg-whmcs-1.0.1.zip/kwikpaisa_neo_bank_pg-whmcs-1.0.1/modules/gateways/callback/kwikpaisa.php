<?php
/**
 * WHMCS KwikPaisa Payment Callback File
 *
 * Verifying that the payment gateway module is active,
 * Validating an Invoice ID, Checking for the existence of a Transaction ID,
 * Logging the Transaction for debugging and Adding Payment to an Invoice.
 */
// Require libraries needed for gateway module functions.
require_once __DIR__ . '/../../../init.php';
require_once __DIR__ . '/../../../includes/functions.php';
require_once __DIR__ . '/../../../includes/gatewayfunctions.php';
require_once __DIR__ . '/../../../includes/invoicefunctions.php';
// Detect module name from filename.
$gatewayModuleName = 'kwikpaisa';
// Fetch gateway configuration parameters.
$gatewayParams = getGatewayVariables($gatewayModuleName);
$Gateway_name = "KwikPaisa NEO Bank";
// Die if module is not active.
if (!$gatewayParams['type']) {
    die("Module Not Activated");
}
$appId              = $gatewayParams["appId"];
$secretKey          = $gatewayParams["secretKey"];
//Gateway response parameters

$kwikpaisaOrderId    = $_POST["midorderid"];
$invoiceId          = substr($kwikpaisaOrderId, strpos($kwikpaisaOrderId, "_") + 1);
$transactionId       = $_POST['txn_id'];
$paymentAmount       = $_POST["txn_amount"];
$txnstatus = $_POST['txn_status'];
// Validate Callback Invoice ID.
//$invoiceId          = checkCbInvoiceID($invoiceId, $gatewayParams['name']);
//$error = "";
if ($txnstatus == 'SUCCESS')
{
    # Apply Payment to Invoice: invoiceid, transactionid, amount paid, fees, modulename
    addInvoicePayment($invoiceId, $transactionId, $paymentAmount, "0.0", $Gateway_name);
    # Successful
    # Save to Gateway Log: name, data array, status
    logTransaction($gatewayParams["name"], $_POST, "Successful");

    header("Location: ".$gatewayParams['systemurl']."viewinvoice.php?id=" . $invoiceId."&paymentsuccess=true");
}
else 
{
    # Save to Gateway Log: name, data array, status
    logTransaction($gatewayParams["name"], $_POST, "Unsuccessful-".$error . ". Please check kwikpaisa dashboard for order id: ".$kwikpaisaOrderId);
    header("Location: ".$gatewayParams['systemurl']."viewinvoice.php?id=" . $invoiceId."&paymentfailed=true");
}