<?php
/**
 * WHMCS KwikPaisa NEO Bank Payment Gateway Module
 */
if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}
/**
 * Define module related meta data.
 * @return array
 */
function kwikpaisa_MetaData()
{
    return array(
        'DisplayName' => 'KwikPaisa NEO Bank',
        'APIVersion' => '1.0.1',
        'DisableLocalCredtCardInput' => true,
        'TokenisedStorage' => false,
    );
}
/**
 * Define KwikPaisa NEO Bank gateway configuration options.
 * @return array
 */
function kwikpaisa_config()
{
    return array(
        'FriendlyName' => array(
            'Type' => 'System',
            'Value' => 'KwikPaisa NEO Bank',
        ),
        'appId' => array(
            'FriendlyName' => 'MID KEY',
            'Type' => 'text',
            'Size' => '50',
            'Description' => 'KwikPaisa NEO Bank "App Id". Available <a href="https://www.kwikpaisa.com/" target="_blank" style="bottom-border:1px dotted;">HERE</a>',
        ),
        'secretKey' => array(
            'FriendlyName' => 'MID SALT KEY',
            'Type' => 'password',
            'Size' => '50',
            'Description' => 'KwikPaisa NEO Bank "Secret Key" shared during activation API Key',
        ),
        'themeLogo' => array(
            'FriendlyName' => 'Logo URL',
            'Type' => 'text',
            'Size' => '50',
            'Description' => 'ONLY "http<strong>s</strong>://"; else leave blank.<br/><small>Size: 128px X 128px (or higher) | File Type: png/jpg/gif/ico</small>',
        ),
        'themeColor' => array(
            'FriendlyName' => 'Theme Color',
            'Type' => 'text',
            'Size' => '15',
            'Default' => '#15A4D3',
            'Description' => 'The colour of checkout form elements',
        ),
        'testMode' => array(
            'FriendlyName' => 'Test Mode',
            'Type' => 'yesno',
            'Description' => 'Tick to enable test mode',
        ),
    );
}
/**
 * Payment link.
 * Required by third party payment gateway modules only.
 * Defines the HTML output displayed on an invoice. Typically consists of an
 * HTML form that will take the user to the payment gateway endpoint.
 * @param array $params Payment Gateway Module Parameters
 * @return string
 */
function cashfree_link($params)
{
    // Gateway Configuration Parameters
    $appId          = $params['appId'];
    $testMode       = $params['testMode'];
    
    // Invoice Parameters
    $invoiceId      = $params['invoiceid'];
    $amount         = $params['amount'];
    $currencyCode   = $params['currency'];
    
    // Client Parameters
    $firstname      = $params['clientdetails']['firstname'];
    $lastname       = $params['clientdetails']['lastname'];
    $email          = $params['clientdetails']['email'];
    $phone          = $params['clientdetails']['phonenumber'];

    // System Parameters
    $systemUrl      = $params['systemurl'];
    $returnUrl      = $params['returnurl'];
    $moduleName     = $params['paymentmethod'];

    //KwikPaisa NEO Bank Payment Gateway request parameters
    $kp_request                     = array();
    $kp_request['appId']            = $appId;
    $kp_request['orderId']          = 'KwikPaisaWhmcs_'.$invoiceId;
    $kp_request['orderAmount']      = $amount;
    $kp_request['orderCurrency']    = $currencyCode;
    $kp_request['orderNote']        = $invoiceId;
    $kp_request['customerName']     = $firstname.' '.$lastname;
    $kp_request['customerEmail']    = $email;
    $kp_request['customerPhone']    = $phone;
    $kp_request['returnUrl']        = $systemUrl . 'modules/gateways/callback/' . $moduleName . '.php';
    $kp_request['notifyUrl']        = $systemUrl . 'modules/gateways/callback/' . $moduleName . '_notify.php';
    $kp_request['source']           = "whmcs";
    $kp_request['signature']        = generateKwikPaisaSignature($cf_request,$params);

    $langPayNow = $params['langpaynow'];
    $apiEndpoint = ($params['testMode'] == 'on') ? 'https://pispp.kwikpaisa.com' : 'https://pispp.kwikpaisa.com';  
    $url = $apiEndpoint."/whmcs_checkout";
    $htmlOutput = '<form method="post" action="' . $url . '">';
    foreach ($cf_request as $k => $v) {
        $htmlOutput .= '<input type="hidden" name="' . $k . '" value="' . ($v) . '" />';
    }
    $htmlOutput .= '<input type="submit" value="' . $langPayNow . '" />';
    $htmlOutput .= '</form>';

    return $htmlOutput;
}

function generateKwikPaisaSignature($kp_request, $params)
{
    // get secret key from your config
    $secretKey      = $params['secretKey'];
    ksort($kp_request);
    $signatureData = "";
    foreach ($kp_request as $key => $value){
        $signatureData .= $key.$value;
    }
    
    $signature = hash_hmac('sha256', $signatureData, $secretKey,true);
    $signature = base64_encode($signature);
    return $signature;
}